import sqlite3
from pathlib import Path

DATABASE_PATH = Path(__file__).parent / "vacation.db"


def get_connection() -> sqlite3.Connection:
    """Create and configure a database connection."""
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database() -> None:
    """Create the required tables if they do not exist."""
    with get_connection() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS attendance (
                user_id INTEGER NOT NULL,
                username TEXT,
                first_name TEXT NOT NULL,
                activity_id TEXT NOT NULL,
                status TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, activity_id)
            )
            """
        )


def save_attendance(
    user_id: int,
    username: str | None,
    first_name: str,
    activity_id: str,
    status: str,
) -> None:
    """Insert or update a participant's attendance status."""
    allowed_statuses = {"confirmed", "maybe", "declined"}

    if status not in allowed_statuses:
        raise ValueError(f"Unsupported status: {status}")

    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO attendance (
                user_id,
                username,
                first_name,
                activity_id,
                status
            )
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id, activity_id)
            DO UPDATE SET
                username = excluded.username,
                first_name = excluded.first_name,
                status = excluded.status,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                user_id,
                username,
                first_name,
                activity_id,
                status,
            ),
        )


def get_attendance(activity_id: str) -> list[sqlite3.Row]:
    """Return attendance records for one activity."""
    with get_connection() as connection:
        records = connection.execute(
            """
            SELECT first_name, username, status
            FROM attendance
            WHERE activity_id = ?
            ORDER BY
                CASE status
                    WHEN 'confirmed' THEN 1
                    WHEN 'maybe' THEN 2
                    ELSE 3
                END,
                first_name
            """,
            (activity_id,),
        ).fetchall()

    return records


def get_user_plans(user_id: int) -> list[sqlite3.Row]:
    """Return confirmed and tentative plans for one participant."""
    with get_connection() as connection:
        records = connection.execute(
            """
            SELECT activity_id, status
            FROM attendance
            WHERE user_id = ?
              AND status IN ('confirmed', 'maybe')
            ORDER BY updated_at
            """,
            (user_id,),
        ).fetchall()

    return records

def get_reminder_recipients(
    activity_id: str,
) -> list[sqlite3.Row]:
    """Return users who confirmed or may attend an activity."""
    with get_connection() as connection:
        records = connection.execute(
            """
            SELECT
                user_id,
                username,
                first_name,
                status
            FROM attendance
            WHERE activity_id = ?
              AND status IN ('confirmed', 'maybe')
            ORDER BY first_name
            """,
            (activity_id,),
        ).fetchall()

    return records
