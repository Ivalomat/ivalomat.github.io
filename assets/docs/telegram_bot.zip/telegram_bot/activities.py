from datetime import date
from pathlib import Path
from typing import Any

import yaml


ACTIVITIES_PATH = Path(__file__).parent / "activities.yaml"

REQUIRED_FIELDS = {
    "title",
    "date",
    "end_date",
    "time",
    "meeting_point",
    "status",
    "estimated_cost",
    "map_url",
    "booking_url",
    "weather_location",
    "description",
}

ALLOWED_STATUSES = {
    "proposed",
    "confirmed",
    "reserved",
    "cancelled",
}


def validate_activities(
    data: dict[str, dict[str, Any]],
) -> None:
    """Validate the complete activities dictionary."""
    if not isinstance(data, dict) or not data:
        raise ValueError(
            "At least one activity must be defined."
        )

    for activity_id, activity in data.items():
        if not isinstance(activity_id, str):
            raise ValueError(
                "Activity identifiers must be strings."
            )

        if not isinstance(activity, dict):
            raise ValueError(
                f"Activity '{activity_id}' does not have a valid format."
            )

        missing_fields = REQUIRED_FIELDS - set(activity)

        if missing_fields:
            missing = ", ".join(sorted(missing_fields))
            raise ValueError(
                f"Activity '{activity_id}' is missing: {missing}"
            )

        for field in REQUIRED_FIELDS:
            if not isinstance(activity[field], str):
                raise ValueError(
                    f"'{activity_id}.{field}' must be written as text."
                )

        try:
            start_date = date.fromisoformat(activity["date"])
        except ValueError as error:
            raise ValueError(
                f"'{activity_id}.date' must use the YYYY-MM-DD format."
            ) from error

        try:
            end_date = date.fromisoformat(activity["end_date"])
        except ValueError as error:
            raise ValueError(
                f"'{activity_id}.end_date' must use the YYYY-MM-DD format."
            ) from error

        if end_date < start_date:
            raise ValueError(
                f"The end date of '{activity_id}' cannot be earlier than the start date."
            )

        if activity["status"] not in ALLOWED_STATUSES:
            allowed = ", ".join(sorted(ALLOWED_STATUSES))

            raise ValueError(
                f"Invalid status in '{activity_id}'. "
                f"Allowed values: {allowed}"
            )

        for url_field in ("map_url", "booking_url"):
            url = activity[url_field].strip()

            if url and not url.startswith(("http://", "https://")):
                raise ValueError(
                    f"'{activity_id}.{url_field}' must be an http/https URL or be left empty."
                )


def load_activities() -> dict[str, dict[str, Any]]:
    """Load and validate activities from activities.yaml."""
    if not ACTIVITIES_PATH.exists():
        raise FileNotFoundError(
            f"File not found: {ACTIVITIES_PATH}"
        )

    with ACTIVITIES_PATH.open(
        "r",
        encoding="utf-8",
    ) as file:
        data = yaml.safe_load(file)

    validate_activities(data)

    return data


def save_activities(
    data: dict[str, dict[str, Any]],
) -> None:
    """Validate and safely save activities to activities.yaml."""
    validate_activities(data)

    temporary_path = ACTIVITIES_PATH.with_suffix(".yaml.tmp")

    try:
        with temporary_path.open(
            "w",
            encoding="utf-8",
        ) as file:
            yaml.safe_dump(
                data,
                file,
                allow_unicode=True,
                sort_keys=False,
                default_flow_style=False,
                width=100,
            )

        temporary_path.replace(ACTIVITIES_PATH)

    finally:
        if temporary_path.exists():
            temporary_path.unlink()
