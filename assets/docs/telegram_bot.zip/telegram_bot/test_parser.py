"""Simple tests for the rule-based message parser."""

from core.parser import parse


TEST_CASES = [
    (
        "I am going to Turin",
        "confirm",
        "torino",
    ),
    (
        "I am not going to Parma",
        "decline",
        "parma",
    ),
    (
        "Maybe I will go to Lugano",
        "maybe",
        "lugano",
    ),
    (
        "Who is going to Naples?",
        "attendees",
        "napoli",
    ),
    (
        "How much does Liguria cost?",
        "price",
        "liguria",
    ),
    (
        "What are we doing tomorrow?",
        "tomorrow",
        None,
    ),
    (
        "What are we doing today?",
        "today",
        None,
    ),
    (
        "What is the plan for Pisa?",
        "schedule",
        "pisa",
    ),
    (
        "I want to go to Como",
        "confirm",
        "como",
    ),
    (
        "How does the bot work?",
        "help",
        None,
    ),
    (
        "Show me my plans",
        "my_plans",
        None,
    ),
    (
        "Who confirmed for the hiking?",
        "attendees",
        "hiking",
    ),
]


def run_tests() -> None:
    failures = []

    for message, expected_action, expected_activity in TEST_CASES:
        result = parse(message)

        action_is_correct = result.action == expected_action
        activity_is_correct = result.activity == expected_activity

        if action_is_correct and activity_is_correct:
            print(f"✅ {message}")
            continue

        failures.append(
            {
                "message": message,
                "expected_action": expected_action,
                "received_action": result.action,
                "expected_activity": expected_activity,
                "received_activity": result.activity,
            }
        )

        print(f"❌ {message}")
        print(
            f"   Action: expected={expected_action}, "
            f"received={result.action}"
        )
        print(
            f"   Activity: expected={expected_activity}, "
            f"received={result.activity}"
        )

    print()

    if failures:
        raise AssertionError(
            f"{len(failures)} tests failed."
        )

    print(f"All tests passed: {len(TEST_CASES)}")


if __name__ == "__main__":
    run_tests()
