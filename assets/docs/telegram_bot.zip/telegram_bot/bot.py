import logging
import os

import yaml

from copy import deepcopy
from core.parser import parse

from datetime import date, datetime, timedelta, time
from zoneinfo import ZoneInfo

from urllib.parse import urlencode

from weather_service import (
    WeatherServiceError,
    get_weather_forecast,
)

from activities import (
    ALLOWED_STATUSES,
    load_activities,
    save_activities,
)

from dotenv import load_dotenv

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    Update,
)

from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from database import (
    get_attendance,
    get_reminder_recipients,
    get_user_plans,
    initialize_database,
    save_attendance,
)

load_dotenv()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

ADMIN_USER_ID_RAW = os.getenv("ADMIN_USER_ID")

if ADMIN_USER_ID_RAW:
    ADMIN_USER_ID = int(ADMIN_USER_ID_RAW)
else:
    ADMIN_USER_ID = None

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

ACTIVITIES = load_activities()
ITALY_TIMEZONE = ZoneInfo("Europe/Rome")
REMINDER_HOUR = 19
REMINDER_MINUTE = 0


MAIN_MENU = ReplyKeyboardMarkup(
    [
        ["🗓 View itinerary", "🧳 My plans"],
        ["📍 Today's plan", "⏭ Next activity"],
        ["❓ Help"],
    ],
    resize_keyboard=True,
    is_persistent=True,
)

WEEKDAYS_EN = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
]

MONTHS_EN = [
    "",
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
]

STATUS_LABELS = {
    "proposed": "🟡 Proposed",
    "confirmed": "🟢 Confirmed",
    "reserved": "🔵 Reserved",
    "cancelled": "🔴 Cancelled",
}

EDITABLE_ACTIVITY_FIELDS = {
    "title": "title",
    "date": "date",
    "end_date": "end_date",
    "end": "end_date",
    "time": "time",
    "schedule": "time",
    "meeting_point": "meeting_point",
    "meeting": "meeting_point",
    "point": "meeting_point",
    "status": "status",
    "estimated_cost": "estimated_cost",
    "cost": "estimated_cost",
    "price": "estimated_cost",
    "map_url": "map_url",
    "map": "map_url",
    "booking_url": "booking_url",
    "booking": "booking_url",
    "tickets": "booking_url",
    "description": "description",
}
def create_calendar_url(activity_id: str) -> str:
    """Create a prefilled Google Calendar URL for an activity."""
    activity = ACTIVITIES[activity_id]

    start_date = datetime.strptime(
        activity["date"],
        "%Y-%m-%d",
    ).date()

    end_date = datetime.strptime(
        activity.get("end_date", activity["date"]),
        "%Y-%m-%d",
    ).date()

    # Google Calendar treats the end of all-day events as exclusive.
    calendar_end_date = end_date + timedelta(days=1)

    dates = (
        f"{start_date.strftime('%Y%m%d')}/"
        f"{calendar_end_date.strftime('%Y%m%d')}"
    )

    details = (
        f"{activity['description']}\n\n"
        f"Time: {activity['time']}\n"
        "Activity organized with August Vacation Assistant."
    )

    parameters = {
        "action": "TEMPLATE",
        "text": activity["title"],
        "dates": dates,
        "details": details,
        "location": activity["meeting_point"],
    }

    return (
        "https://calendar.google.com/calendar/render?"
        + urlencode(parameters)
    )

def is_admin(user_id: int) -> bool:
    """Return whether the Telegram user is the bot administrator."""
    return (
        ADMIN_USER_ID is not None
        and user_id == ADMIN_USER_ID
    )

def attendance_keyboard(activity_id: str) -> InlineKeyboardMarkup:
    """Create attendance, calendar and external link buttons."""
    activity = ACTIVITIES[activity_id]

    keyboard = [
        [
            InlineKeyboardButton(
                "✅ I'm going",
                callback_data=f"attendance|{activity_id}|confirmed",
            ),
            InlineKeyboardButton(
                "🤔 Maybe",
                callback_data=f"attendance|{activity_id}|maybe",
            ),
        ],
        [
            InlineKeyboardButton(
                "❌ I can't go",
                callback_data=f"attendance|{activity_id}|declined",
            ),
            InlineKeyboardButton(
                "👥 View attendees",
                callback_data=f"attendees|{activity_id}",
            ),
        ],
        [
            InlineKeyboardButton(
                "📅 Add to Google Calendar",
                url=create_calendar_url(activity_id),
            )
        ],
    ]

    external_links = []

    map_url = activity.get("map_url", "").strip()
    booking_url = activity.get("booking_url", "").strip()

    if map_url:
        external_links.append(
            InlineKeyboardButton(
                "🗺 Open map",
                url=map_url,
            )
        )

    if booking_url:
        external_links.append(
            InlineKeyboardButton(
                "🎟 Booking or tickets",
                url=booking_url,
            )
        )

    if external_links:
        keyboard.append(external_links)

    keyboard.append(
        [
            InlineKeyboardButton(
                "🌤 View weather",
                callback_data=f"weather|{activity_id}",
            )
        ]
    )

    return InlineKeyboardMarkup(keyboard)

def format_english_date(date_value: str) -> str:
    """Convert an ISO date into a readable English date."""
    parsed_date = date.fromisoformat(date_value)
    weekday = WEEKDAYS_EN[parsed_date.weekday()]
    month = MONTHS_EN[parsed_date.month]
    return f"{weekday}, {month} {parsed_date.day}"


def format_activity_dates(activity: dict) -> str:
    """Format the date range of an activity in English."""
    start_date = date.fromisoformat(activity["date"])
    end_date = date.fromisoformat(activity.get("end_date", activity["date"]))

    if start_date == end_date:
        return format_english_date(activity["date"])

    start_weekday = WEEKDAYS_EN[start_date.weekday()]
    end_weekday = WEEKDAYS_EN[end_date.weekday()]
    start_month = MONTHS_EN[start_date.month]
    end_month = MONTHS_EN[end_date.month]

    if start_date.month == end_date.month and start_date.year == end_date.year:
        return (
            f"{start_weekday}, {start_month} {start_date.day} to "
            f"{end_weekday}, {end_month} {end_date.day}"
        )

    return (
        f"{start_weekday}, {start_month} {start_date.day} to "
        f"{end_weekday}, {end_month} {end_date.day}"
    )


def format_activity(activity_id: str) -> str:
    """Format one activity as a Telegram message."""
    activity = ACTIVITIES[activity_id]

    status = STATUS_LABELS.get(
        activity["status"],
        activity["status"],
    )

    return (
        f"📍 {activity['title']}\n\n"
        f"📅 Date: {format_activity_dates(activity)}\n"
        f"🕒 Time: {activity['time']}\n"
        f"🚉 Meeting point: {activity['meeting_point']}\n"
        f"📌 Status: {status}\n"
        f"💶 Estimated cost: {activity['estimated_cost']}\n\n"
        f"{activity['description']}"
    )

def find_activity(search_text: str) -> str | None:
    """Find an activity by ID, title or date."""
    normalized = search_text.lower().strip()

    if normalized in ACTIVITIES:
        return normalized

    for activity_id, activity in ACTIVITIES.items():
        searchable_text = (
            f"{activity_id} "
            f"{activity['title']} "
            f"{activity['date']}"
        ).lower()

        if normalized in searchable_text:
            return activity_id

    return None

def find_next_activity(
    reference_date: date | None = None,
) -> str | None:
    """Return the next current or future activity."""
    current_date = reference_date or date.today()

    possible_activities = []

    for activity_id, activity in ACTIVITIES.items():
        start_date = date.fromisoformat(activity["date"])
        end_date = date.fromisoformat(
            activity.get("end_date", activity["date"])
        )

        # Include activities currently in progress.
        if end_date >= current_date:
            possible_activities.append(
                (
                    max(start_date, current_date),
                    start_date,
                    activity_id,
                )
            )

    if not possible_activities:
        return None

    possible_activities.sort()

    return possible_activities[0][2]

def format_attendees(activity_id: str) -> str:
    """Build an attendance summary."""
    records = get_attendance(activity_id)
    title = ACTIVITIES[activity_id]["title"]

    confirmed = []
    maybe = []
    declined = []

    for record in records:
        name = record["first_name"]

        if record["status"] == "confirmed":
            confirmed.append(name)
        elif record["status"] == "maybe":
            maybe.append(name)
        else:
            declined.append(name)

    def names_or_none(names: list[str]) -> str:
        return ", ".join(names) if names else "Nobody"

    return (
        f"👥 Attendance for {title}\n\n"
        f"✅ Confirmed: {names_or_none(confirmed)}\n"
        f"🤔 Maybe: {names_or_none(maybe)}\n"
        f"❌ Not attending: {names_or_none(declined)}"
    )


async def start(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Present the bot and show the main menu."""
    user = update.effective_user

    message = (
        f"Hi, {user.first_name}.\n\n"
        "I am the assistant for our August vacation plans.\n\n"
        "You can use the menu below or these commands:\n\n"
        "/plan — View the itinerary\n"
        "/activity lugano — View an activity\n"
        "/attendees lugano — View participants\n"
        "/myplans — View your activities\n"
        "/today — View today's plan\n"
        "/next — View the next activity\n"
        "/help — Show help"
    )

    await update.message.reply_text(
        message,
        reply_markup=MAIN_MENU,
    )

async def plan(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the itinerary."""
    lines = ["🗓 Tentative August itinerary\n"]

    for activity_id, activity in ACTIVITIES.items():
        lines.append(
            f"• {format_activity_dates(activity)} — {activity['title']}\n" 
            f"  /activity_{activity_id}"
        )

    lines.append(
        "\nYou can also write, for example:\n"
        "/activity lugano"
    )

    await update.message.reply_text(
    "\n".join(lines),
    reply_markup=MAIN_MENU,
) 


async def activity_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show one activity and its attendance buttons."""
    if not context.args:
        await update.message.reply_text(
            "Enter an activity after the command.\n\n"
            "Example:\n"
            "/activity lugano"
        )
        return

    search_text = " ".join(context.args)
    activity_id = find_activity(search_text)

    if activity_id is None:
        await update.message.reply_text(
            "I could not find that activity.\n"
            "Use /plan to see the available names."
        )
        return

    await update.message.reply_text(
        format_activity(activity_id),
        reply_markup=attendance_keyboard(activity_id),
    )


async def direct_activity_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Handle commands such as /activity_lugano."""
    command = update.message.text.split()[0]
    activity_id = command.removeprefix("/activity_").split("@")[0]

    if activity_id not in ACTIVITIES:
        await update.message.reply_text("Activity not found.")
        return

    await update.message.reply_text(
        format_activity(activity_id),
        reply_markup=attendance_keyboard(activity_id),
    )


async def attendance_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Store a response sent through an inline button."""
    query = update.callback_query
    await query.answer()

    parts = query.data.split("|")

    if len(parts) != 3:
        await query.message.reply_text("The received response is not valid.")
        return

    _, activity_id, status = parts

    if activity_id not in ACTIVITIES:
        await query.message.reply_text("That activity no longer exists.")
        return

    if ACTIVITIES[activity_id]["status"] == "cancelled":
        await query.message.reply_text(
        "This activity is cancelled and no longer accepts attendance responses."
    )
        return

    user = query.from_user

    save_attendance(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name,
        activity_id=activity_id,
        status=status,
    )

    labels = {
        "confirmed": "✅ Your attendance is confirmed.",
        "maybe": "🤔 Your response was saved as “Maybe”.",
        "declined": "❌ Your response was saved as “Not attending”.",
    }

    await query.message.reply_text(
        f"{labels[status]}\n"
        f"Activity: {ACTIVITIES[activity_id]['title']}"
    )


async def attendees_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show attendance after pressing the attendees button."""
    query = update.callback_query
    await query.answer()

    parts = query.data.split("|")

    if len(parts) != 2:
        return

    _, activity_id = parts

    if activity_id not in ACTIVITIES:
        await query.message.reply_text("Activity not found.")
        return

    await query.message.reply_text(format_attendees(activity_id))


async def attendees_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show attendance using a command."""
    if not context.args:
        await update.message.reply_text(
            "Example:\n/attendees lugano"
        )
        return

    activity_id = find_activity(" ".join(context.args))

    if activity_id is None:
        await update.message.reply_text("Activity not found.")
        return

    await update.message.reply_text(format_attendees(activity_id))


async def today(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show today's activity."""
    today_iso = date.today().isoformat()

    matching_activities = [
        activity_id
        for activity_id, activity in ACTIVITIES.items()
        if activity["date"] == today_iso
    ]

    if not matching_activities:
        await update.message.reply_text(
            "There is no activity scheduled for today."
        )
        return

    for activity_id in matching_activities:
        await update.message.reply_text(
            format_activity(activity_id),
            reply_markup=attendance_keyboard(activity_id),
        )

async def my_plans(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the current user's confirmed and tentative plans."""
    user = update.effective_user
    records = get_user_plans(user.id)

    if not records:
        await update.message.reply_text(
            "You do not have any confirmed or tentative activities yet.\n\n"
            "Use /plan to view the activities."
        )
        return

    confirmed = []
    maybe = []

    for record in records:
        activity_id = record["activity_id"]

        if activity_id not in ACTIVITIES:
            continue

        activity = ACTIVITIES[activity_id]
        line = (
            f"• {format_activity_dates(activity)} — "
            f"{activity['title']}\n"
            f"  /activity_{activity_id}"
        ) 

        if record["status"] == "confirmed":
            confirmed.append(line)
        elif record["status"] == "maybe":
            maybe.append(line)

    sections = ["🧳 My August plans"]

    if confirmed:
        sections.append(
            "\n✅ Confirmed\n" + "\n".join(confirmed)
        )

    if maybe:
        sections.append(
            "\n🤔 Maybe\n" + "\n".join(maybe)
        )

    await update.message.reply_text(
    "\n".join(sections),
    reply_markup=MAIN_MENU,
) 

async def next_activity(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the next current or future activity."""
    activity_id = find_next_activity()

    if activity_id is None:
        await update.message.reply_text(
            "There are no future activities left in the itinerary.",
            reply_markup=MAIN_MENU,
        )
        return

    activity = ACTIVITIES[activity_id]
    start_date = date.fromisoformat(activity["date"])
    today_date = date.today()

    if start_date < today_date:
        introduction = "🚉 Activity currently in progress"
    elif start_date == today_date:
        introduction = "📍 The next activity is today"
    else:
        remaining_days = (start_date - today_date).days

        if remaining_days == 1:
            time_message = "1 day left."
        else:
            time_message = f"{remaining_days} days left."

        introduction = (
            f"⏭ Next activity\n"
            f"{time_message}"
        )

    await update.message.reply_text(
        f"{introduction}\n\n"
        f"{format_activity(activity_id)}",
        reply_markup=attendance_keyboard(activity_id),
    )

async def send_activity_message(
    update: Update,
    activity_id: str,
) -> None:
    """Send one activity with its attendance and calendar buttons."""
    if activity_id not in ACTIVITIES:
        await update.message.reply_text(
            "I could not find that activity.",
            reply_markup=MAIN_MENU,
        )
        return

    await update.message.reply_text(
        format_activity(activity_id),
        reply_markup=attendance_keyboard(activity_id),
    )


async def send_tomorrow_activity(
    update: Update,
) -> None:
    """Show the activity scheduled for tomorrow."""
    tomorrow_date = date.today() + timedelta(days=1)

    matching_activities = []

    for activity_id, activity in ACTIVITIES.items():
        start_date = date.fromisoformat(activity["date"])
        end_date = date.fromisoformat(
            activity.get("end_date", activity["date"])
        )

        if start_date <= tomorrow_date <= end_date:
            matching_activities.append(activity_id)

    if not matching_activities:
        await update.message.reply_text(
            "There is no activity scheduled for tomorrow.",
            reply_markup=MAIN_MENU,
        )
        return

    for activity_id in matching_activities:
        await update.message.reply_text(
            "📅 Tomorrow's plan\n\n"
            f"{format_activity(activity_id)}",
            reply_markup=attendance_keyboard(activity_id),
        )


async def save_natural_attendance(
    update: Update,
    activity_id: str,
    status: str,
) -> None:
    """Save attendance detected from a natural-language message."""
    if activity_id not in ACTIVITIES:
        await update.message.reply_text(
            "I could not find that activity.",
            reply_markup=MAIN_MENU,
        )
        return

    if ACTIVITIES[activity_id]["status"] == "cancelled":
        await update.message.reply_text(
            "This activity is cancelled and no longer accepts attendance responses.",
            reply_markup=MAIN_MENU,
        )
        return

    allowed_statuses = {
        "confirmed",
        "maybe",
        "declined",
    }

    if status not in allowed_statuses:
        await update.message.reply_text(
            "I could not save that response.",
            reply_markup=MAIN_MENU,
        )
        return

    user = update.effective_user

    save_attendance(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name,
        activity_id=activity_id,
        status=status,
    )

    status_messages = {
        "confirmed": "✅ Your attendance is confirmed.",
        "maybe": "🤔 Your response was saved as “Maybe”.",
        "declined": "❌ Your response was saved as “Not attending”.",
    }

    await update.message.reply_text(
        f"{status_messages[status]}\n"
        f"Activity: {ACTIVITIES[activity_id]['title']}",
        reply_markup=MAIN_MENU,
    )

async def menu_handler(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Handle menu buttons and natural-language messages."""
    text = update.message.text.strip()

    # ---------------------------------------------------------
    # Persistent menu buttons
    # ---------------------------------------------------------

    if text == "🗓 View itinerary":
        await plan(update, context)
        return

    if text == "🧳 My plans":
        await my_plans(update, context)
        return

    if text == "📍 Today's plan":
        await today(update, context)
        return

    if text == "⏭ Next activity":
        await next_activity(update, context)
        return

    if text == "❓ Help":
        await help_command(update, context)
        return

    # ---------------------------------------------------------
    # Natural-language parser
    # ---------------------------------------------------------

    parsed = parse(text)

    # Examples:
    # "What are we doing today?"
    # "What is today's plan?"
    if parsed.action == "today":
        await today(update, context)
        return

    # Examples:
    # "What are we doing tomorrow?"
    # "Is anything planned for tomorrow?"
    if parsed.action == "tomorrow":
        await send_tomorrow_activity(update)
        return

    # Examples:
    # "What is next?"
    # "What is the next activity?"
    if parsed.action == "next":
        await next_activity(update, context)
        return

    # Examples:
    # "Show me my plans"
    # "Which activities am I signed up for?"
    if parsed.action == "my_plans":
        await my_plans(update, context)
        return

    # Examples:
    # "Help"
    # "What can you do?"
    if parsed.action == "help":
        await help_command(update, context)
        return

    # Examples:
    # "What is the plan for Turin?"
    # "What time is Lugano?"
    # "Give me the details for Parma"
    if (
        parsed.action == "schedule"
        and parsed.activity
    ):
        await send_activity_message(
            update,
            parsed.activity,
        )
        return

    # Examples:
    # "How much does Naples cost?"
    # "What is the price of Liguria?"
    if (
        parsed.action == "price"
        and parsed.activity
    ):
        activity = ACTIVITIES[parsed.activity]

        await update.message.reply_text(
            f"💶 {activity['title']}\n\n"
            f"Estimated cost: {activity['estimated_cost']}",
            reply_markup=attendance_keyboard(parsed.activity),
        )
        return

    # Examples:
    # "Who is going to Lugano?"
    # "Show me the attendees for Turin"
    if (
        parsed.action == "attendees"
        and parsed.activity
    ):
        await update.message.reply_text(
            format_attendees(parsed.activity),
            reply_markup=attendance_keyboard(parsed.activity),
        )
        return

    # Examples:
    # "I am going to Parma"
    # "Count me in for Turin"
    # "Yes, I am going to Lugano"
    if (
        parsed.action == "confirm"
        and parsed.activity
    ):
        await save_natural_attendance(
            update,
            parsed.activity,
            "confirmed",
        )
        return

    # Examples:
    # "Maybe I will go to Naples"
    # "I am not sure about Liguria"
    if (
        parsed.action == "maybe"
        and parsed.activity
    ):
        await save_natural_attendance(
            update,
            parsed.activity,
            "maybe",
        )
        return

    # Examples:
    # "I am not going to Parma"
    # "Cancel my attendance for Turin"
    if (
        parsed.action == "decline"
        and parsed.activity
    ):
        await save_natural_attendance(
            update,
            parsed.activity,
            "declined",
        )
        return

    # ---------------------------------------------------------
    # Partial understanding
    # ---------------------------------------------------------

    if parsed.action and not parsed.activity:
        await update.message.reply_text(
            "I understood what you want to do, but I could not identify the activity.\n\n"
            "Include the destination too, for example:\n"
            "• I am going to Turin\n"
            "• Who is going to Lugano?\n"
            "• How much does Naples cost?",
            reply_markup=MAIN_MENU,
        )
        return

    if parsed.activity and not parsed.action:
        await update.message.reply_text(
            f"I identified the activity “{ACTIVITIES[parsed.activity]['title']}”, "
            "but I did not understand what you want to know.\n\n"
            "You can ask, for example:\n"
            "• What is the plan?\n"
            "• How much does it cost?\n"
            "• Who is going?\n"
            "• I am going",
            reply_markup=attendance_keyboard(parsed.activity),
        )
        return

    # ---------------------------------------------------------
    # Message not understood
    # ---------------------------------------------------------

    await update.message.reply_text(
        "I did not understand your message.\n\n"
        "Try phrases such as:\n"
        "• What is the plan for Turin?\n"
        "• How much does Lugano cost?\n"
        "• Who is going to Naples?\n"
        "• I am going a Parma\n"
        "• Maybe I will go to Liguria\n"
        "• I am not going hiking\n"
        "• What are we doing tomorrow?",
        reply_markup=MAIN_MENU,
    )

async def reload_activities_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Reload activities.yaml without restarting the bot."""
    global ACTIVITIES

    user = update.effective_user

    if not is_admin(user.id):
        await update.message.reply_text(
            "You do not have permission to use this command."
        )
        return

    try:
        updated_activities = load_activities()
    except (FileNotFoundError, ValueError, yaml.YAMLError) as error:
        await update.message.reply_text(
            "I could not reload the itinerary.\n\n"
            f"Error: {error}"
        )
        return

    ACTIVITIES = updated_activities

    await update.message.reply_text(
        "✅ Itinerary reloaded successfully.\n"
        f"Available activities: {len(ACTIVITIES)}",
        reply_markup=MAIN_MENU,
    )

async def help_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the available commands."""
    message = (
        "Available commands:\n\n"
        "/start — Open the main menu\n"
        "/plan — View the full itinerary\n"
        "/activity lugano — View an activity\n"
        "/attendees lugano — See who is participating\n"
        "/myplans — View your activities\n"
        "/today — View today's plan\n"
        "/next — View the next activity\n"
        "/weather — View the weather forecast\n"
        "/help — Show this help"
    )

    if is_admin(update.effective_user.id):
        message += (
            "\n\n🔧 Administration\n"
            "/reload — Reload activities.yaml\n"
            "/edit — Modify an activity\n\n"
            "Format:\n"
            "/edit activity field new_value"
        )

    await update.message.reply_text(
        message,
        reply_markup=MAIN_MENU,
    )

async def send_activity_reminders(
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Send reminders for activities beginning tomorrow."""
    today_date = datetime.now(ITALY_TIMEZONE).date()
    tomorrow_date = today_date + timedelta(days=1)

    tomorrow_activities = []

    for activity_id, activity in ACTIVITIES.items():
        start_date = date.fromisoformat(activity["date"])

        if (
            start_date == tomorrow_date
            and activity["status"] != "cancelled"
        ):
            tomorrow_activities.append(activity_id)

    if not tomorrow_activities:
        logging.info(
            "There are no activities to remind users about on %s.",
            tomorrow_date,
        )
        return

    for activity_id in tomorrow_activities:
        activity = ACTIVITIES[activity_id]
        recipients = get_reminder_recipients(activity_id)

        if not recipients:
            logging.info(
                "Activity %s has no participants.",
                activity_id,
            )
            continue

        reminder_message = (
            "⏰ Vacation reminder\n\n"
            f"📍 Tomorrow: {activity['title']}\n"
            f"📅 Date: {format_activity_dates(activity)}\n"
            f"🕒 Time: {activity['time']}\n"
            f"🚉 Meeting point: {activity['meeting_point']}\n"
            f"💶 Estimated cost: {activity['estimated_cost']}\n\n"
            f"{activity['description']}"
        )

        for recipient in recipients:
            try:
                await context.bot.send_message(
                    chat_id=recipient["user_id"],
                    text=reminder_message,
                    reply_markup=attendance_keyboard(activity_id),
                )

                logging.info(
                    "Reminder sent to %s for %s.",
                    recipient["user_id"],
                    activity_id,
                )

            except Exception:
                logging.exception(
                    "Could not send the reminder to %s.",
                    recipient["user_id"],
                )


async def test_reminder_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Send a test reminder to the administrator."""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text(
            "You do not have permission to use this command."
        )
        return

    if not context.args:
        await update.message.reply_text(
            "Enter an activity.\n\n"
            "Example:\n"
            "/testreminder torino"
        )
        return

    activity_id = find_activity(" ".join(context.args))

    if activity_id is None:
        await update.message.reply_text(
            "I could not find that activity."
        )
        return

    activity = ACTIVITIES[activity_id]

    reminder_message = (
        "🧪 Reminder test\n\n"
        f"📍 Next activity: {activity['title']}\n"
        f"📅 Date: {format_activity_dates(activity)}\n"
        f"🕒 Time: {activity['time']}\n"
        f"🚉 Meeting point: {activity['meeting_point']}\n"
        f"💶 Estimated cost: {activity['estimated_cost']}\n\n"
        f"{activity['description']}"
    )

    await update.message.reply_text(
        reminder_message,
        reply_markup=attendance_keyboard(activity_id),
    )

async def edit_activity_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Edit one field of an activity from Telegram."""
    global ACTIVITIES

    user = update.effective_user

    if not is_admin(user.id):
        await update.message.reply_text(
            "You do not have permission to use this command.",
            reply_markup=MAIN_MENU,
        )
        return

    raw_text = update.message.text.strip()
    parts = raw_text.split(maxsplit=3)

    if len(parts) < 4:
        await update.message.reply_text(
            "Incorrect format.\n\n"
            "Use:\n"
            "/edit activity field new_value\n\n"
            "Examples:\n"
            "/edit torino time 08:00–21:00\n"
            "/edit torino meeting_point Milano Centrale\n"
            "/edit torino estimated_cost 45 € per person\n"
            "/edit torino status confirmed\n"
            "/edit torino booking_url https://example.com",
            reply_markup=MAIN_MENU,
        )
        return

    _, activity_input, field_input, new_value = parts

    activity_id = activity_input.lower().strip()
    field_input = field_input.lower().strip()
    new_value = new_value.strip()

    if activity_id not in ACTIVITIES:
        await update.message.reply_text(
            f"There is no activity with the identifier “{activity_id}”.\n\n"
            "Use /plan to view the identifiers.",
            reply_markup=MAIN_MENU,
        )
        return

    field_name = EDITABLE_ACTIVITY_FIELDS.get(field_input)

    if field_name is None:
        await update.message.reply_text(
            "That field cannot be modified.\n\n"
            "Allowed fields:\n"
            "• title\n"
            "• date\n"
            "• end_date or end\n"
            "• time or schedule\n"
            "• meeting_point or meeting\n"
            "• status\n"
            "• estimated_cost, cost or price\n"
            "• map_url or map\n"
            "• booking_url, booking or tickets\n"
            "• description",
            reply_markup=MAIN_MENU,
        )
        return

    empty_markers = {
        "-",
        "empty",
        "empty",
        "none",
        "null",
    }

    if (
        field_name in {"map_url", "booking_url"}
        and new_value.lower() in empty_markers
    ):
        new_value = ""

    if (
        not new_value
        and field_name not in {"map_url", "booking_url"}
    ):
        await update.message.reply_text(
            "That field cannot be empty.",
            reply_markup=MAIN_MENU,
        )
        return

    if field_name == "status":
        new_value = new_value.lower()

        if new_value not in ALLOWED_STATUSES:
            allowed = ", ".join(sorted(ALLOWED_STATUSES))

            await update.message.reply_text(
                f"Invalid status.\n\n"
                f"Allowed statuses: {allowed}",
                reply_markup=MAIN_MENU,
            )
            return

    updated_activities = deepcopy(ACTIVITIES)
    previous_value = updated_activities[activity_id][field_name]

    updated_activities[activity_id][field_name] = new_value

    try:
        save_activities(updated_activities)
        ACTIVITIES = load_activities()

    except (
        FileNotFoundError,
        ValueError,
        yaml.YAMLError,
        OSError,
    ) as error:
        await update.message.reply_text(
            "I could not save the change.\n\n"
            f"Error: {error}",
            reply_markup=MAIN_MENU,
        )
        return

    shown_previous_value = previous_value or "(empty)"
    shown_new_value = new_value or "(empty)"

    await update.message.reply_text(
        "✅ Activity updated successfully.\n\n"
        f"📍 Activity: {ACTIVITIES[activity_id]['title']}\n"
        f"🔧 Field: {field_name}\n"
        f"Before: {shown_previous_value}\n"
        f"Now: {shown_new_value}",
        reply_markup=attendance_keyboard(activity_id),
    )

def weather_recommendation(
    precipitation_probability: int,
    precipitation_sum: float,
    wind_speed: float,
    temperature_max: float,
) -> str:
    """Generate a simple recommendation from forecast values."""
    recommendations = []

    if precipitation_probability >= 60 or precipitation_sum >= 3:
        recommendations.append("bring a raincoat or umbrella")
    elif precipitation_probability >= 30:
        recommendations.append("consider bringing a light raincoat")

    if temperature_max >= 30:
        recommendations.append(
            "bring water and sunscreen, and avoid intense sun"
        )

    if temperature_max <= 12:
        recommendations.append("bring a warm layer")

    if wind_speed >= 35:
        recommendations.append(
            "be careful because of strong winds"
        )

    if not recommendations:
        return "No special precautions are required."

    return "Recommendation: " + "; ".join(recommendations) + "."


def format_weather_forecast(
    location_name: str,
    country: str,
    forecasts: list,
) -> str:
    """Format one or more forecast days for Telegram."""
    location_label = location_name

    if country:
        location_label += f", {country}"

    lines = [
        f"🌤 Forecast for {location_label}",
        "",
    ]

    for forecast in forecasts:
        readable_date = format_english_date(
            forecast.forecast_date.isoformat()
        )

        recommendation = weather_recommendation(
            precipitation_probability=forecast.precipitation_probability,
            precipitation_sum=forecast.precipitation_sum,
            wind_speed=forecast.wind_speed_max,
            temperature_max=forecast.temperature_max,
        )

        lines.extend(
            [
                f"📅 {readable_date}",
                f"• {forecast.description}",
                (
                    f"• Temperature: {forecast.temperature_min:.0f}–"
                    f"{forecast.temperature_max:.0f} °C"
                ),
                (
                    "• Rain probability: "
                    f"{forecast.precipitation_probability}%"
                ),
                (
                    f"• Estimated precipitation: "
                    f"{forecast.precipitation_sum:.1f} mm"
                ),
                (
                    f"• Maximum wind speed: "
                    f"{forecast.wind_speed_max:.0f} km/h"
                ),
                f"• {recommendation}",
                "",
            ]
        )

    lines.append(
        "Weather source: Open-Meteo. "
        "The forecast may change."
    )

    return "\n".join(lines)

async def send_activity_weather(
    update: Update,
    activity_id: str,
) -> None:
    """Retrieve and send the forecast for one activity."""
    if activity_id not in ACTIVITIES:
        await update.effective_message.reply_text(
            "I could not find that activity.",
            reply_markup=MAIN_MENU,
        )
        return

    activity = ACTIVITIES[activity_id]
    location = activity["weather_location"].strip()

    if not location:
        await update.effective_message.reply_text(
            "This activity does not have a weather location configured.",
            reply_markup=MAIN_MENU,
        )
        return

    start_date = date.fromisoformat(activity["date"])
    end_date = date.fromisoformat(activity["end_date"])
    today_date = datetime.now(ITALY_TIMEZONE).date()

    if end_date < today_date:
        await update.effective_message.reply_text(
            "This activity has already ended and has no future forecast.",
            reply_markup=MAIN_MENU,
        )
        return

    days_until_start = (start_date - today_date).days

    if days_until_start > 16:
        await update.effective_message.reply_text(
            f"The forecast for “{activity['title']}” is not available yet.\n\n"
            f"There are {days_until_start} days left, and the service provides "
            "a maximum 16-day forecast.",
            reply_markup=MAIN_MENU,
        )
        return

    query_start = max(start_date, today_date)

    # Avoid requesting beyond the supported 16-day horizon.
    maximum_end = today_date + timedelta(days=16)
    query_end = min(end_date, maximum_end)

    await update.effective_message.reply_text(
        f"Checking the weather for {activity['title']}…"
    )

    try:
        coordinates, forecasts = await get_weather_forecast(
            location=location,
            start_date=query_start,
            end_date=query_end,
        )

    except WeatherServiceError as error:
        await update.effective_message.reply_text(
            "I could not retrieve the forecast.\n\n"
            f"Error: {error}",
            reply_markup=MAIN_MENU,
        )
        return

    message = format_weather_forecast(
        location_name=coordinates.name,
        country=coordinates.country,
        forecasts=forecasts,
    )

    await update.effective_message.reply_text(
        message,
        reply_markup=attendance_keyboard(activity_id),
    )

async def weather_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the weather forecast for an activity."""
    if not context.args:
        await update.message.reply_text(
            "Enter an activity.\n\n"
            "Examples:\n"
            "/weather como\n"
            "/weather hiking\n"
            "/weather lugano",
            reply_markup=MAIN_MENU,
        )
        return

    activity_id = find_activity(" ".join(context.args))

    if activity_id is None:
        await update.message.reply_text(
            "I could not find that activity.\n"
            "Use /plan to see the available names.",
            reply_markup=MAIN_MENU,
        )
        return

    await send_activity_weather(
        update,
        activity_id,
    )

async def weather_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Handle the weather button for an activity."""
    query = update.callback_query
    await query.answer()

    parts = query.data.split("|")

    if len(parts) != 2:
        await query.message.reply_text(
            "The weather request is not valid."
        )
        return

    _, activity_id = parts

    await send_activity_weather(
        update,
        activity_id,
    )

def main() -> None:
    """Initialize and start the bot."""
    if not TOKEN:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN was not found in the .env file"
        )

    initialize_database()

    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("plan", plan))
    application.add_handler(CommandHandler("activity", activity_command))
    application.add_handler(
        CommandHandler("attendees", attendees_command)
    )
    application.add_handler(CommandHandler("today", today))
    application.add_handler(CommandHandler("next", next_activity))
    application.add_handler(CommandHandler("myplans", my_plans))
    application.add_handler(CommandHandler("help", help_command))

    for activity_id in ACTIVITIES:
        application.add_handler(
            CommandHandler(
                f"activity_{activity_id}",
                direct_activity_command,
            )
        )

    application.add_handler(
        CallbackQueryHandler(
            attendance_callback,
            pattern=r"^attendance\|",
        )
    )

    application.add_handler(
        CommandHandler(
            "reload",
            reload_activities_command,
        )
    )

    application.add_handler(
        CommandHandler(
            "testreminder",
            test_reminder_command,
        )
    )

    application.add_handler(
        CommandHandler(
            "edit",
            edit_activity_command,
        )
    )

    application.add_handler(
        CommandHandler(
            "weather",
            weather_command,
        )
    )

    application.add_handler(
        CallbackQueryHandler(
            attendees_callback,
            pattern=r"^attendees\|",
        )
    )

    application.add_handler(
        CallbackQueryHandler(
            weather_callback,
            pattern=r"^weather\|",
        )
    )

    application.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            menu_handler,
        )
    )   

    if application.job_queue is None:
        raise RuntimeError(
            "JobQueue is not available. Install "
            'python-telegram-bot with the "[job-queue]" extra.'
        )

        application.job_queue.run_daily(
        send_activity_reminders,
        time=time(
            hour=REMINDER_HOUR,
            minute=REMINDER_MINUTE,
            tzinfo=ITALY_TIMEZONE,
        ),
        name="daily_activity_reminders",
    )

    print("Bot started. Press Ctrl+C to stop it.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
