"""Weather forecasts using the Open-Meteo APIs."""

from dataclasses import dataclass
from datetime import date
from typing import Any

import httpx


GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"


WEATHER_DESCRIPTIONS = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Dense freezing drizzle",
    61: "Light rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Light snowfall",
    73: "Moderate snowfall",
    75: "Heavy snowfall",
    77: "Snow grains",
    80: "Light rain showers",
    81: "Moderate rain showers",
    82: "Heavy rain showers",
    85: "Light snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with light hail",
    99: "Thunderstorm with heavy hail",
}


@dataclass(frozen=True)
class Coordinates:
    """Coordinates resolved from a place name."""

    name: str
    country: str
    latitude: float
    longitude: float
    timezone: str


@dataclass(frozen=True)
class DailyForecast:
    """Weather forecast for one calendar day."""

    forecast_date: date
    description: str
    temperature_max: float
    temperature_min: float
    precipitation_probability: int
    precipitation_sum: float
    wind_speed_max: float


class WeatherServiceError(Exception):
    """Raised when weather information cannot be retrieved."""


async def geocode_location(location: str) -> Coordinates:
    """Convert a location name into geographical coordinates."""
    parameters = {
        "name": location,
        "count": 1,
        "language": "en",
        "format": "json",
    }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.get(
                GEOCODING_URL,
                params=parameters,
            )
            response.raise_for_status()
            payload = response.json()

    except (httpx.HTTPError, ValueError) as error:
        raise WeatherServiceError(
            "Could not look up the location."
        ) from error

    results = payload.get("results", [])

    if not results:
        raise WeatherServiceError(
            f"Location “{location}” was not found."
        )

    result = results[0]

    return Coordinates(
        name=result["name"],
        country=result.get("country", ""),
        latitude=float(result["latitude"]),
        longitude=float(result["longitude"]),
        timezone=result.get("timezone", "auto"),
    )


async def fetch_daily_forecast(
    coordinates: Coordinates,
    start_date: date,
    end_date: date,
) -> list[DailyForecast]:
    """Retrieve daily weather between two dates."""
    parameters = {
        "latitude": coordinates.latitude,
        "longitude": coordinates.longitude,
        "daily": ",".join(
            [
                "weather_code",
                "temperature_2m_max",
                "temperature_2m_min",
                "precipitation_probability_max",
                "precipitation_sum",
                "wind_speed_10m_max",
            ]
        ),
        "timezone": "auto",
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
    }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.get(
                FORECAST_URL,
                params=parameters,
            )
            response.raise_for_status()
            payload = response.json()

    except httpx.HTTPStatusError as error:
        try:
            reason = error.response.json().get("reason")
        except ValueError:
            reason = None

        if reason:
            raise WeatherServiceError(reason) from error

        raise WeatherServiceError(
            "The weather service rejected the request."
        ) from error

    except (httpx.HTTPError, ValueError) as error:
        raise WeatherServiceError(
            "Could not connect to the weather service."
        ) from error

    daily: dict[str, Any] = payload.get("daily", {})
    dates = daily.get("time", [])

    if not dates:
        raise WeatherServiceError(
            "No forecast is available for those dates."
        )

    forecasts = []

    for index, date_text in enumerate(dates):
        weather_code = int(daily["weather_code"][index])

        forecasts.append(
            DailyForecast(
                forecast_date=date.fromisoformat(date_text),
                description=WEATHER_DESCRIPTIONS.get(
                    weather_code,
                    f"Weather code {weather_code}",
                ),
                temperature_max=float(
                    daily["temperature_2m_max"][index]
                ),
                temperature_min=float(
                    daily["temperature_2m_min"][index]
                ),
                precipitation_probability=int(
                    daily["precipitation_probability_max"][index] or 0
                ),
                precipitation_sum=float(
                    daily["precipitation_sum"][index] or 0
                ),
                wind_speed_max=float(
                    daily["wind_speed_10m_max"][index] or 0
                ),
            )
        )

    return forecasts


async def get_weather_forecast(
    location: str,
    start_date: date,
    end_date: date,
) -> tuple[Coordinates, list[DailyForecast]]:
    """Resolve a location and retrieve its forecast."""
    coordinates = await geocode_location(location)

    forecasts = await fetch_daily_forecast(
        coordinates=coordinates,
        start_date=start_date,
        end_date=end_date,
    )

    return coordinates, forecasts
