import logging
import os
from datetime import date, datetime, timedelta
from urllib.parse import urlencode

from activities import load_activities
from dotenv import load_dotenv
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
)

from database import (
    get_attendance,
    get_user_plans,
    initialize_database,
    save_attendance,
)

load_dotenv()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

ACTIVITIES = load_activities()

def create_calendar_url(activity_id: str) -> str:
    """Create a prefilled Google Calendar URL for an activity."""
    activity = ACTIVITIES[activity_id]

    start_date = datetime.strptime(
        activity["date"],
        "%Y-%m-%d",
    ).date()

    end_date = datetime.strptime(
        activity.get("end_date", activity["date"]),
        "%Y-%m-%d",
    ).date()

    # Google Calendar treats the end of all-day events as exclusive.
    calendar_end_date = end_date + timedelta(days=1)

    dates = (
        f"{start_date.strftime('%Y%m%d')}/"
        f"{calendar_end_date.strftime('%Y%m%d')}"
    )

    details = (
        f"{activity['description']}\n\n"
        f"Time: {activity['time']}\n"
        "Activity organized with August Vacation Assistant."
    )

    parameters = {
        "action": "TEMPLATE",
        "text": activity["title"],
        "dates": dates,
        "details": details,
        "location": activity["meeting_point"],
    }

    return (
        "https://calendar.google.com/calendar/render?"
        + urlencode(parameters)
    )

def attendance_keyboard(activity_id: str) -> InlineKeyboardMarkup:
    """Create attendance and calendar buttons for an activity."""
    keyboard = [
        [
            InlineKeyboardButton(
                "✅ I'm going",
                callback_data=f"attendance|{activity_id}|confirmed",
            ),
            InlineKeyboardButton(
                "🤔 Maybe",
                callback_data=f"attendance|{activity_id}|maybe",
            ),
        ],
        [
            InlineKeyboardButton(
                "❌ I can't go",
                callback_data=f"attendance|{activity_id}|declined",
            ),
            InlineKeyboardButton(
                "👥 View attendees",
                callback_data=f"attendees|{activity_id}",
            ),
        ],
        [
            InlineKeyboardButton(
                "📅 Add to Google Calendar",
                url=create_calendar_url(activity_id),
            )
        ],
    ]

    return InlineKeyboardMarkup(keyboard)

def format_activity(activity_id: str) -> str:
    """Format one activity as a Telegram message."""
    activity = ACTIVITIES[activity_id]

    return (
        f"📍 {activity['title']}\n\n"
        f"📅 Date: {activity['date']}\n"
        f"🕒 Time: {activity['time']}\n"
        f"🚉 Meeting point: {activity['meeting_point']}\n\n"
        f"{activity['description']}"
    )


def find_activity(search_text: str) -> str | None:
    """Find an activity by ID, title or date."""
    normalized = search_text.lower().strip()

    if normalized in ACTIVITIES:
        return normalized

    for activity_id, activity in ACTIVITIES.items():
        searchable_text = (
            f"{activity_id} "
            f"{activity['title']} "
            f"{activity['date']}"
        ).lower()

        if normalized in searchable_text:
            return activity_id

    return None


def format_attendees(activity_id: str) -> str:
    """Build an attendance summary."""
    records = get_attendance(activity_id)
    title = ACTIVITIES[activity_id]["title"]

    confirmed = []
    maybe = []
    declined = []

    for record in records:
        name = record["first_name"]

        if record["status"] == "confirmed":
            confirmed.append(name)
        elif record["status"] == "maybe":
            maybe.append(name)
        else:
            declined.append(name)

    def names_or_none(names: list[str]) -> str:
        return ", ".join(names) if names else "Nobody"

    return (
        f"👥 Attendance for {title}\n\n"
        f"✅ Confirmed: {names_or_none(confirmed)}\n"
        f"🤔 Maybe: {names_or_none(maybe)}\n"
        f"❌ Not attending: {names_or_none(declined)}"
    )


async def start(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Present the bot."""
    user = update.effective_user

    message = (
        f"Hi, {user.first_name}.\n\n"
        "I am the assistant for our August vacation plans.\n\n"
        "Main commands:\n"
        "/plan — View the itinerary\n"
        "/activity lugano — View an activity\n"
        "/attendees lugano — View participants\n"
        "/today — View today's plan\n"
        "/help — View all commands"
    )

    await update.message.reply_text(message)


async def plan(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the itinerary."""
    lines = ["🗓 Tentative August itinerary\n"]

    for activity_id, activity in ACTIVITIES.items():
        lines.append(
            f"• {activity['date']} — {activity['title']}\n"
            f"  /activity_{activity_id}"
        )

    lines.append(
        "\nYou can also write, for example:\n"
        "/activity lugano"
    )

    await update.message.reply_text("\n".join(lines))


async def activity_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show one activity and its attendance buttons."""
    if not context.args:
        await update.message.reply_text(
            "Enter an activity after the command.\n\n"
            "Example:\n"
            "/activity lugano"
        )
        return

    search_text = " ".join(context.args)
    activity_id = find_activity(search_text)

    if activity_id is None:
        await update.message.reply_text(
            "I could not find that activity.\n"
            "Use /plan to see the available names."
        )
        return

    await update.message.reply_text(
        format_activity(activity_id),
        reply_markup=attendance_keyboard(activity_id),
    )


async def direct_activity_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Handle commands such as /activity_lugano."""
    command = update.message.text.split()[0]
    activity_id = command.removeprefix("/activity_").split("@")[0]

    if activity_id not in ACTIVITIES:
        await update.message.reply_text("Activity not found.")
        return

    await update.message.reply_text(
        format_activity(activity_id),
        reply_markup=attendance_keyboard(activity_id),
    )


async def attendance_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Store a response sent through an inline button."""
    query = update.callback_query
    await query.answer()

    parts = query.data.split("|")

    if len(parts) != 3:
        await query.message.reply_text("The received response is not valid.")
        return

    _, activity_id, status = parts

    if activity_id not in ACTIVITIES:
        await query.message.reply_text("That activity no longer exists.")
        return

    user = query.from_user

    save_attendance(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name,
        activity_id=activity_id,
        status=status,
    )

    labels = {
        "confirmed": "✅ Your attendance is confirmed.",
        "maybe": "🤔 Your response was saved as “Maybe”.",
        "declined": "❌ Your response was saved as “Not attending”.",
    }

    await query.message.reply_text(
        f"{labels[status]}\n"
        f"Activity: {ACTIVITIES[activity_id]['title']}"
    )


async def attendees_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show attendance after pressing the attendees button."""
    query = update.callback_query
    await query.answer()

    parts = query.data.split("|")

    if len(parts) != 2:
        return

    _, activity_id = parts

    if activity_id not in ACTIVITIES:
        await query.message.reply_text("Activity not found.")
        return

    await query.message.reply_text(format_attendees(activity_id))


async def attendees_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show attendance using a command."""
    if not context.args:
        await update.message.reply_text(
            "Example:\n/attendees lugano"
        )
        return

    activity_id = find_activity(" ".join(context.args))

    if activity_id is None:
        await update.message.reply_text("Activity not found.")
        return

    await update.message.reply_text(format_attendees(activity_id))


async def today(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show today's activity."""
    today_iso = date.today().isoformat()

    matching_activities = [
        activity_id
        for activity_id, activity in ACTIVITIES.items()
        if activity["date"] == today_iso
    ]

    if not matching_activities:
        await update.message.reply_text(
            "There is no activity scheduled for today."
        )
        return

    for activity_id in matching_activities:
        await update.message.reply_text(
            format_activity(activity_id),
            reply_markup=attendance_keyboard(activity_id),
        )

async def my_plans(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the current user's confirmed and tentative plans."""
    user = update.effective_user
    records = get_user_plans(user.id)

    if not records:
        await update.message.reply_text(
            "You do not have any confirmed or tentative activities yet.\n\n"
            "Use /plan to view the activities."
        )
        return

    confirmed = []
    maybe = []

    for record in records:
        activity_id = record["activity_id"]

        if activity_id not in ACTIVITIES:
            continue

        activity = ACTIVITIES[activity_id]
        line = (
            f"• {activity['date']} — {activity['title']}\n"
            f"  /activity_{activity_id}"
        )

        if record["status"] == "confirmed":
            confirmed.append(line)
        elif record["status"] == "maybe":
            maybe.append(line)

    sections = ["🧳 My August plans"]

    if confirmed:
        sections.append(
            "\n✅ Confirmed\n" + "\n".join(confirmed)
        )

    if maybe:
        sections.append(
            "\n🤔 Maybe\n" + "\n".join(maybe)
        )

    await update.message.reply_text("\n".join(sections))

async def help_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Show the available commands."""
    message = (
        "Available commands:\n\n"
        "/start — Start the bot\n"
        "/plan — View the full itinerary\n"
        "/activity lugano — View an activity\n"
        "/attendees lugano — See who is participating\n"
        "/myplans — View your activities\n"
        "/today — View today's plan\n"\
        "/help — Show this help"
    )

    await update.message.reply_text(message)


def main() -> None:
    """Initialize and start the bot."""
    if not TOKEN:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN was not found in the .env file"
        )

    initialize_database()

    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("plan", plan))
    application.add_handler(CommandHandler("activity", activity_command))
    application.add_handler(
        CommandHandler("attendees", attendees_command)
    )
    application.add_handler(CommandHandler("today", today))
    application.add_handler(CommandHandler("myplans", my_plans))
    application.add_handler(CommandHandler("help", help_command))

    for activity_id in ACTIVITIES:
        application.add_handler(
            CommandHandler(
                f"activity_{activity_id}",
                direct_activity_command,
            )
        )

    application.add_handler(
        CallbackQueryHandler(
            attendance_callback,
            pattern=r"^attendance\|",
        )
    )
    application.add_handler(
        CallbackQueryHandler(
            attendees_callback,
            pattern=r"^attendees\|",
        )
    )

    print("Bot started. Press Ctrl+C to stop it.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
